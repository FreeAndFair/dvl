﻿/*
 * Authors: Morten, Michael
 * Team: PX3
 * Date: 12-12-2011
 */

using System.Windows.Controls;

namespace DigitalVoterList.Views
{

    /// <summary>
    /// Interaction logic for ManualVoterValidationView.xaml
    /// </summary>
    public partial class ManualVoterValidationView : UserControl
    {
        public ManualVoterValidationView()
        {
            InitializeComponent();
        }
    }
}