﻿/*
 * Authors: Michael
 * Team: PX3
 * Date: 12-12-2011
 */

using System.Windows;

namespace DigitalVoterList.Views
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
    }
}
