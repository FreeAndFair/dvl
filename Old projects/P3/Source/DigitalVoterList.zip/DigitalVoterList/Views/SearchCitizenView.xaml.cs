﻿/*
 * Authors: Morten, Michael
 * Team: PX3
 * Date: 12-12-2011
 */


namespace DigitalVoterList.Views
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for SearchCitizenView.xaml
    /// </summary>
    public partial class SearchCitizenView : UserControl
    {
        public SearchCitizenView()
        {
            InitializeComponent();
        }
    }
}
