﻿/*
 * Authors: Morten, Michael
 * Team: PX3
 * Date: 12-12-2011
 */

using System.Windows.Controls;

namespace DigitalVoterList.Views
{
    /// <summary>
    /// Interaction logic for VoterIdentificationView.xaml
    /// </summary>
    public partial class VoterIdentificationView : UserControl
    {
        public VoterIdentificationView()
        {
            InitializeComponent();
        }
    }
}
