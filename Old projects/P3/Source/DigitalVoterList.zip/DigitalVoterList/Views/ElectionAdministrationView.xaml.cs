﻿/*
 * Authors: Morten, Michael
 * Team: PX3
 * Date: 12-12-2011
 */

using System.Windows.Controls;

namespace DigitalVoterList.Views
{
    /// <summary>
    /// Interaction logic for ElectionAdministrationView.xaml
    /// </summary>
    public partial class ElectionAdministrationView : UserControl
    {
        public ElectionAdministrationView()
        {
            InitializeComponent();
        }
    }
}
